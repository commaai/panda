#pragma once

#define PANDA_CAN_CNT 3U

#include "opendbc/safety/can.h"
